import java.util.HashMap;

puplic class MapHashmatique {
}