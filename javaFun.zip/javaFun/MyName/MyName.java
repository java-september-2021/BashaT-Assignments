public class MyName {
    public static void main(String[] args) {
        System.out.println("My name is Basha Taylor");
        System.out.println("I am 53 years old");
        System.out.println("My hometown is Plainville, CT");
    }
}