import java.util.ArrayList;
import java.util.*;
public class BasicJavaTest {
    public static void main(String[] args) {
        BasicJava javaTest = new BasicJava();
    }   

}   
        