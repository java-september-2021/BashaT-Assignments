// Create a Project class that has the fields of name and description
public class Project {
    private String name;
    private String description;
    public Project (){  
        return (name);

    }
    public Project(String name){

    }

    public Project(String name: String description){

    }
}

